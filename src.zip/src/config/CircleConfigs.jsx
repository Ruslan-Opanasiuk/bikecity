const CircleConfigs = {
  E5B1: {
    outerRadius: 50,
    strokeWidth: 7.66
  },
  E5B4: {
    outerRadius: 43,
    strokeWidth: 5.75
  },
  E5B4text: {
    outerRadius: 24,
    strokeWidth: 3
  },
  B7: {
    outerRadius: 10,
    strokeWidth: 0
  },
  B7bicycle: {
    outerRadius: 14,
    strokeWidth: 4
  },
  B7citycentre: {
    outerRadius: 22.5,
    strokeWidth: 0
  },
  B7interchange: {
    outerRadius: 16,
    strokeWidth: 0
  }
}

export default CircleConfigs;